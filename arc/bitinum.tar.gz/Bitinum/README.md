Bitinum 0.9.3 [Un]

Proof of Work SHA256 Cryptocurrency based on Bitcoin 0.8.99

1 Minute Block targets //revised as of this version 

Fast, progressive (4 blocks over 80) difficulty adjustments of max 10% up/20% down

First 4 years = subsidy of 100 coins

After 4 years = 50 Coin per block, halving every 4 years

Minimum subsidy of 10 coin after final halving at 25 coins per block
 
999 mln Max Coins Ever.

RPC Port = 3011

P2P Port = 3010

QR Code Support

